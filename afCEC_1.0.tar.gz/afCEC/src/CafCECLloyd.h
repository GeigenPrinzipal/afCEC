#ifndef C_AFCEC_LLOYD
#define C_AFCEC_LLOYD

#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace arma ;

//   -*-   -*-   -*-

//   -*-   -*-   -*-

#endif
